import React, { useState } from "react";
import "./App.css";
import { FuncBtn } from "./components/FuncBtn";
import { TransactionModule } from "./components/TransactionHistoryModule/TransactionModule";
import { UserModule } from "./components/UserInfoModule/UserModule";
import { LoginPage } from "./components/UserLoginModule/LoginPage";
import { TransactionStatisticsModule } from "./components/TransactionStatisticsModule/TransactionStatisticsModule";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import transactionData from "./services/data.json";

const transactionList = transactionData.data;

const currencyConversions = [
  { currency: "USD", purchase: 27.55, sale: 27.65 },
  { currency: "EUR", purchase: 30.0, sale: 30.1 },
];


function App() {
  const [currPage, setCurrPage] = useState(0);
  const [visibility, setVisibility] = useState(0);

  const handleChangePage = (pgi) => {
    setCurrPage(pgi);
    setTimeout(() => setVisibility(pgi), 200);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route
          path="/main"
          element={
            <div className="app-container">
              <UserModule
                balance={24000.0}
                conversions={currencyConversions}
                onChangePage={(pgi) => handleChangePage(pgi)}
              />
              {visibility === 0 && (
                <div style={{ opacity: currPage === 0 ? 1 : 0 }}>
                  <TransactionModule />
                </div>
              )}
              {visibility === 1 && (
                <div style={{ opacity: currPage === 1 ? 1 : 0 }}>
                  <TransactionStatisticsModule transactions={transactionList} />
                </div>
              )}
            </div>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
