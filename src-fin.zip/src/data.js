let data = {
    fetchData: [],
    isLoading: false,
    error: null,
    query: "",
}

export default data;