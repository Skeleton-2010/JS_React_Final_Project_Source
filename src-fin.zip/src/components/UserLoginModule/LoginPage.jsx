
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";
import { FuncBtn } from "../FuncBtn";

export const LoginPage = ({
}) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    let formErrors = {};

    if (isRegistering && !/^[a-zA-Z0-9 ]+$/.test(formData.username)) {
      formErrors.username = "Username must contain only numbers or letters";
    }

    if (formData.password.length < 5) {
      formErrors.password = "Password must be at least 5 characters long";
    }

    if (!formData.email.includes("@")) {
      formErrors.email = "Your E-mail doesn't seem to be valid";
    }

    if (isRegistering && formData.password !== formData.confirmPassword) {
      formErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(formErrors);

    return Object.keys(formErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      navigate("/main");
    }
  };

  return (
    <div className="login-container">
      <div className="window-login">
        <h1 className="window-title">Money Guard</h1>
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-inputs-container">
            {isRegistering && (
              <div className="input-container">
                <input
                  type="text"
                  name="username"
                  placeholder="Name"
                  value={formData.username}
                  onChange={handleChange}
                  className="inp-email inp-login"
                />
                {errors.username && (
                  <p className="txt-error">{errors.username}</p>
                )}
              </div>
            )}

            <input
              type="input"
              placeholder="E-mail"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="inp-name inp-login"
            />
            {errors.password && <p className="txt-error">{errors.email}</p>}

            <input
              type="input"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              className="inp-password inp-login"
            />
            {errors.password && <p className="txt-error">{errors.password}</p>}

            {isRegistering && (
              <div className="input-container">
                <input
                  type="input"
                  name="confirmPassword"
                  placeholder="Confirm password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="inp-confirm inp-login"
                />
                {errors.confirmPassword && (
                  <p className="txt-error">{errors.confirmPassword}</p>
                )}
              </div>
            )}
          </div>
          <FuncBtn
            clas="btn-login"
            txt={isRegistering ? "Register" : "Log in"}
            hasStyle={1}
          />
        </form>
        <a
          onClick={() => {
            setIsRegistering(!isRegistering);
            setErrors({});
            setFormData({
              username: "",
              email: "",
              password: "",
              confirmPassword: "",
            });
          }}
          className="link-toggle-login"
        >
          {isRegistering
            ? `Already have an account? Log in!`
            : "Don't have an account? Register!"}
        </a>
      </div>
    </div>
  );
};


