import { FuncBtn } from "../FuncBtn";
import { TransactionChart } from "./TransactionChart";
import { AddTransactionWindow } from "./AddTransactionWindow";
import { EditTransactionWindow } from "./EditTransactionWindow";
import { useState } from "react";
import "./TransactionModule.css"

export const TransactionModule = () => {
  const [isAddWindowOpen, setAddWindow] = useState(false);
  const [isEditWindowOpen, setEditWindow] = useState(false);
  const [editIdx, setEditIdx] = useState(0);
  const [editInitial, setEditInitial] = useState({
    date: ``,
    type: 1,
    category: 7,
    comment: "",
    sum: 0.0,
  });
  const [transactions, setTransactions] = useState([]);
  const types = ["+", "-"];
  const categories = [
    "Products",
    "Car",
    "Self care",
    "Child care",
    "Household",
    "Education",
    "Leisure",
    "Other",
  ];

  const handleDelete = (idx) => {
    setTransactions((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleAdd = (transactionData) => {
    setTransactions((prev) => [...prev, transactionData]);
    console.log(transactions);
  };

  const handleEdit = (newData) => {
    setTransactions((prev) => {
      const updated = [...prev];
      updated[editIdx] = newData;
      return updated;
    });
  };

  return (
    <div
      className="transaction-module-main"
    >
      {isAddWindowOpen && (
        <AddTransactionWindow
          onClose={() => setAddWindow(false)}
          onAdd={handleAdd}
          categories={categories}
        />
      )}
      {isEditWindowOpen && (
        <EditTransactionWindow
          onClose={() => setEditWindow(false)}
          onEdit={handleEdit}
          initial={editInitial}
          categories={categories}
        />
      )}

      <TransactionChart
        transactions={transactions}
        handleDelete={handleDelete}
        types={types}
        categories={categories}
        onEdit={(idx) => {
          setEditIdx(idx);
          setEditInitial(transactions[idx]);
          setEditWindow(true);
        }}
      />
      <FuncBtn
        txt={"+"}
        func={() => setAddWindow(true)}
        hasStyle={1}
        clas={"transaction-add-btn"}
      />
    </div>
  );
};
