import { FuncBtn } from "../FuncBtn";
import "./TransactionChart.css";

export const TransactionChart = ({
  transactions,
  handleDelete,
  types,
  categories,
  onEdit,
}) => {
  return (
    <div className="transactions-chart">
      <table className="transactions-table">
        <thead className="table-row table-titles transchart-titles">
          <tr>
            <th className="transchart-cell">Date</th>
            <th className="transchart-cell">Type</th>
            <th className="transchart-cell">Category</th>
            <th className="transchart-cell">Comment</th>
            <th className="transchart-cell">Sum</th>
            <th className="transchart-cell">Actions</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((info, idx) => (
            <tr
              key={idx}
              className="table-row table-content transchart-content"
            >
              <td className="transchart-cell">
                <b>{info.date}</b>
              </td>
              <td className="transchart-cell">
                <b>{types[info.type]}</b>
              </td>
              <td className="transchart-cell">{categories[info.category]}</td>
              <td className="transchart-cell">{info.comment}</td>
              <td className="transchart-cell">₴ {info.sum}</td>
              <td className="transchart-cell">
                <FuncBtn
                  txt={"Edit"}
                  func={() => onEdit(idx)}
                  hasStyle={0}
                  clas={"chart-edit-btn"}
                />
                <FuncBtn
                  txt={"Delete"}
                  func={() => handleDelete(idx)}
                  hasStyle={1}
                  clas={"chart-del-btn"}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
