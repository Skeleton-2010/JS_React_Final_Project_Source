import React from "react";
import "./StatisticsList.css";
import { ColorBlock } from "./ColorBlock";
import { ColorText } from "./ColorText";

export const StatisticsList = ({ stats, expense, income}) => {
  return (
    <div>
      <table className="stats-table">
        {stats.map((info, idx) => (
          <tr key={idx} className="stats-row">
            <td width={"5%"}>
              <ColorBlock $col={info.col} />
            </td>
            <td width={"25%"} id="stats-category">
              {info.name}
            </td>
            <td width={"70%"} id="stats-cost">
              {info.cost}
            </td>
          </tr>
        ))}
      </table>
      <h4 className="stats-txt">
        Expenses: <ColorText $col={"#f88"}>{expense}</ColorText>
      </h4>
      <h4 className="stats-txt">
        Income: <ColorText $col={"#fa8"}>{income}</ColorText>
      </h4>
    </div>
  );
};
