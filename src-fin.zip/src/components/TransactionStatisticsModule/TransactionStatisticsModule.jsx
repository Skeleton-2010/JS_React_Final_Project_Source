import { React, useState } from "react";
import { StatisticsList } from "./StatisticsList";
import { StatisticsChart } from "./StatisticsChart";
import "./TransactionStatisticsModule.css";
import { StatisticsDateSearch } from "./StatisticsDateSearch";

export const TransactionStatisticsModule = ({ transactions }) => {
  const [statVals, setStatVals] = useState([]);
  const [expense, setExpense] = useState(0);
  const [income, setIncome] = useState(0);
  const [chartData, setChartData] = useState([]);

  const handleFiltering = (year, month) => {
    let newStatVals = [
      { name: "Products", cost: 0.0, col: "#ebb" },
      { name: "Car", cost: 0.0, col: "#f99" },
      { name: "Self care", cost: 0.0, col: "#cbf" },
      { name: "Child care", cost: 0.0, col: "#67e" },
      { name: "Household ", cost: 0.0, col: "#45e" },
      { name: "Education", cost: 0.0, col: "#8ef" },
      { name: "Leisure", cost: 0.0, col: "#2ca" },
      { name: "Other", cost: 0.0, col: "#0a8" },
    ];
    let IN = 0;
    let EX = 0;
    transactions.forEach((info) => {
      let [TD, TM, TY] = info.date.split("-");
      if (TY === String(year) && TM === String(month)) {
        if (info.type) {
          EX += info.sum;
        } else {
          IN += info.sum;
        }
        newStatVals[info.category].cost = IN - EX;
      }
    });

    setStatVals(newStatVals);
    setExpense(EX);
    setIncome(IN);

    let newChartData = statVals.map((info) => ({
      name: info.name,
      value: Math.abs(info.cost),
    }));

    setChartData(newChartData);
  };

  return (
    <div className="transaction-statistics-main">
      <div className="chart-container">
        <StatisticsDateSearch onChoice={handleFiltering} />
        <StatisticsChart data={chartData} />
      </div>
      <StatisticsList stats={statVals} expense={expense} income={income} />
      {console.log(statVals)}
    </div>
  );
};
