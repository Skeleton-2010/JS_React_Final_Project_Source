import React from "react";
import { PieChart, Pie, Cell } from "recharts";

export const StatisticsChart = ({data}) => {
  const ChartCol = [
    "#ebb", "#f99", "#cbf", "#67e", 
    "#45e", "#8ef", "#2ca", "#0a8",
  ];
  return (
    <PieChart width={480} height={480} className="stats-piechart">
      <Pie
        className="stats-piechart-main"
        dataKey="value"
        nameKey="name"
        cx="50%"
        cy="50%"
        innerRadius={110}
        outerRadius={160}
        fill="#fff"
        label={false}
        data={data}
      >
        {data &&
          data.map((_, idx) => (
            <Cell key={`cell-${idx}`} fill={ChartCol[idx % ChartCol.length]} />
          ))}
      </Pie>
    </PieChart>
  );
};
