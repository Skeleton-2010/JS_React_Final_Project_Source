import { React, useState } from "react";
import { StatisticsList } from "./StatisticsList";
import { StatisticsChart } from "./StatisticsChart";

export const StatisticsDateSearch = ({ onChoice }) => {
  const d = new Date();
  const [year, setYear] = useState(d.getFullYear());
  const [month, setMonth] = useState(d.getMonth());

  const handleChangeYear = (e) => {
    setYear(e.currentTarget.value);
    onChoice(year, month);
  };

  const handleChangeMonth = (e) => {
    setMonth(e.currentTarget.value);
    onChoice(year, month);
  };

  return (
    <div className="transaction-statistics-search">
      <select
        name=""
        id=""
        className="search-select"
        onChange={handleChangeYear}
      >
        <option value="2022">2022</option>
        <option value="2023">2023</option>
        <option value="2024">2024</option>
        <option value="2025">2025</option>
      </select>
      <select
        name=""
        id=""
        className="search-select"
        onChange={handleChangeMonth}
      >
        <option value="1">January</option>
        <option value="2">February</option>
        <option value="3">March</option>
        <option value="4">April</option>
        <option value="5">May</option>
        <option value="6">June</option>
        <option value="7">July</option>
        <option value="8">August</option>
        <option value="9">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>
      </select>
    </div>
  );
};
