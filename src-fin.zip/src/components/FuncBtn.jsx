import styled from "styled-components";

const StyleBtn = styled.button`
  margin: 10px;
  pading: 10px 10px;
  border: none;
  border-radius: 10px;
  text-transform: uppercase;
  font-size: 15px;
  font-weight: 500;
  color: ${(props) => (props.$gradient ? "#fff" : "#000")};
    background: ${(props) =>
      props.$gradient
        ? "linear-gradient( 45deg, #FB0F 0%, #707F 100%);"
        : "linear-gradient( 0, #FFFF 0%, #FFFF 100%);"}'
`;

export const FuncBtn = ({ txt, clas, func, hasStyle }) => {
  return (
    <StyleBtn className={clas} onClick={func} $gradient={hasStyle}>
      {txt}
    </StyleBtn>
  );
};
