import React, { useState } from "react";
import "./UserModule.css";
import { UserCurrencyConversion } from "./UserCurrencyConvertion";
import { UserPageToggle } from "./UserPageToggle";

export const UserModule = ({ balance, conversions, onChangePage}) => {
  return (
    <div className="user-module-main">
      <div className="module-container">
        <UserPageToggle onToggle={(x) => onChangePage(x)} />
        <div className="user-balance-text">
          <div className="balance-text-container">
            <h5 className="balance-title thin-text">Your balance</h5>
            <h1 className="balance-title bold-text">₴ {balance}</h1>
          </div>
        </div>

        <UserCurrencyConversion conversions={conversions} />
      </div>
    </div>
  );
};
