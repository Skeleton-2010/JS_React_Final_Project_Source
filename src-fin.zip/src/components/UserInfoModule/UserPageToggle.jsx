import React, { useState } from "react";
import { BiChart, BiHome } from "react-icons/bi";
import styled from "styled-components";
import "./UserPageToggle.css";

const ToggleText = styled.h3`
  color: #fff;
  font-size: 18px;
  margin: ${(props) => (props.$ch ? 20 : 10)}px;
  font-weight: ${(props) => (props.$ch ? 700 : 400)};
`;

export const UserPageToggle = ({ onToggle }) => {
  const [currVal, setCurrVal] = useState(0);

  const handleClick = (e) => {
    const pg = parseInt(e.currentTarget.value, 10);
    setCurrVal(pg);
    onToggle(pg);
    console.log("SET", pg);
  };

  return (
    <div className="user-toggle">
      <button className="toggle-btn" value={0} onClick={handleClick}>
        <BiHome size={25} className="label-icon" />
        <ToggleText $ch={currVal === 0}>Home</ToggleText>
      </button>

      <button className="toggle-btn" value={1} onClick={handleClick}>
        <BiChart size={25} className="label-icon" />
        <ToggleText $ch={currVal === 1}>Statistics</ToggleText>
      </button>
    </div>
  );
};
