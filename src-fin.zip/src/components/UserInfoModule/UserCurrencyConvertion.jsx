import React from "react";
import "./UserCurrencyConvertion.css";

export const UserCurrencyConversion = ({ conversions }) => {
  return (
    <div className="conversion-chart">
      <table className="conversion-table">
        <thead className="table-row table-titles currconv-titles">
          <tr>
            <th className="currconv-cell">Currency</th>
            <th className="currconv-cell">Purchase</th>
            <th className="currconv-cell">Sale</th>
          </tr>
        </thead>
        <tbody>
          {conversions.map((info, idx) => (
            <tr key={idx} className="table-row table-content currconv-content">
              <td className="currconv-cell">
                <b>{info.currency}</b>
              </td>
              <td className="currconv-cell">{info.purchase}</td>
              <td className="currconv-cell">{info.sale}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
