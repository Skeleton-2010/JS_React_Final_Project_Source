import React from "react";
import "./UserCurrencyConvertion.css";

export const UserCurrencyConversion = ({ conversions }) => {
  return (
    <div className="conversion-chart">
      <table className="conversion-table">
        <thead className="table-row table-titles currconv-titles">
            <tr>
              <th>Currency</th>
              <th>Purchase</th>
              <th>Sale</th>
            </tr>
        </thead>
        <tbody>
          {conversions.map((info, idx) => (
            <tr key={idx} className="table-row table-content currconv-content">
              <td>
                <b>{info.currency}</b>
              </td>
              <td>{info.purchase}</td>
              <td>{info.sale}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
