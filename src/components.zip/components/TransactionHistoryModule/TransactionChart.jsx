import { FuncBtn } from "../FuncBtn";
import "./TransactionChart.css";

export const TransactionChart = ({
  transactions,
  handleDelete,
  types,
  categories,
  onEdit,
}) => {
  return (
    <div className="transactions-chart">
      <table className="transactions-table">
        <thead className="table-row table-titles transchart-titles">
          <tr>
            <th>Date</th>
            <th>Type</th>
            <th>Category</th>
            <th>Comment</th>
            <th>Sum</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((info, idx) => (
            <tr
              key={idx}
              className="table-row table-content transchart-content"
            >
              <td>
                <b>{info.date}</b>
              </td>
              <td>
                <b>{types[info.type]}</b>
              </td>
              <td>{categories[info.category]}</td>
              <td>{info.comment}</td>
              <td>₴ {info.sum}</td>
              <td>
                <FuncBtn
                  txt={"Edit"}
                  func={() => onEdit(idx)}
                  hasStyle={0}
                  clas={"chart-edit-btn"}
                />
                <FuncBtn
                  txt={"Delete"}
                  func={() => handleDelete(idx)}
                  hasStyle={1}
                  clas={"chart-del-btn"}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
