import { FuncBtn } from "../FuncBtn";
import { useState } from "react";
import "./TransactionWindows.css";

export const AddTransactionWindow = ({ onClose, onAdd, categories }) => {
  const d = new Date();
  const [formData, setFormData] = useState({
    date: `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`,
    type: 0,
    category: 7,
    comment: "",
    sum: 0.0,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onAdd(formData);
    onClose();
  };

  return (
    <div className="window-cover">
      <form className="transaction-window-form">
        <h2 className="window-title">Add Transaction</h2>
        <div className="window-inputs">
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleInputChange}
            className="transaction-window-input"
          />
          <select
            name="type"
            value={formData.type}
            onChange={handleInputChange}
            className="transaction-window-input"
          >
            <option value={0}>Income</option>
            <option value={1}>Expense</option>
          </select>
          <select
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            className="transaction-window-input"
          >
            {categories.map((cat, idx) => (
              <option key={idx} value={idx}>
                {cat}
              </option>
            ))}
          </select>
          <input
            name="comment"
            placeholder="Comment here..."
            value={formData.comment}
            onChange={handleInputChange}
            pattern="[0-9]"
            className="transaction-window-input"
          />
          <input
            type="number"
            name="sum"
            placeholder="Amount..."
            value={formData.sum}
            onChange={handleInputChange}
            className="transaction-window-input"
          />
          <FuncBtn
            txt={"Add"}
            func={handleSubmit}
            hasStyle={1}
            clas="transaction-window-btn"
          />
          <FuncBtn
            txt={"Cancel"}
            func={onClose}
            hasStyle={0}
            clas="transaction-window-btn"
          />
        </div>
      </form>
    </div>
  );
};
