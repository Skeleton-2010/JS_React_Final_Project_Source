import React from "react";
import "./StatisticsList.css";
import { ColorBlock } from "./ColorBlock";
import { ColorText } from "./ColorText";

export const StatisticsList = ({ transactions }) => {
  let chartVals = [
    { name: "Products", cost: 0.0, col: "#ebb" },
    { name: "Car", cost: 0.0, col: "#f99" },
    { name: "Self care", cost: 0.0, col: "#cbf" },
    { name: "Child care", cost: 0.0, col: "#67e" },
    { name: "Household ", cost: 0.0, col: "#45e" },
    { name: "Education", cost: 0.0, col: "#8ef" },
    { name: "Leisure", cost: 0.0, col: "#2ca" },
    { name: "Other", cost: 0.0, col: "#0a8" },
  ];

  let expense = 0;
  let income = 0;
  let transCost = 0;

  transactions.map((info, idx) => {
    if (info.type) {
      expense += info.sum;
      transCost = info.sum;
    } else {
      income += info.sum;
      transCost = -info.sum;
    }
    chartVals[info.category].cost += transCost;
  });

  console.log(chartVals);
  return (
    <div>
      <table className="stats-table">
        {chartVals.map((info, idx) => (
          <tr key={idx} className="stats-row">
            <td width={"5%"}>
              <ColorBlock $col={info.col} />
            </td>
            <td width={"25%"} id="stats-category">
              {info.name}
            </td>
            <td width={"70%"} id="stats-cost">
              {info.cost}
            </td>
          </tr>
        ))}
      </table>
      <h4 className="stats-txt">
        Expenses: <ColorText $col={"#f88"}>{expense}</ColorText>
      </h4>
      <h4 className="stats-txt">
        Income: <ColorText $col={"#fa8"}>{income}</ColorText>
      </h4>
    </div>
  );
};
